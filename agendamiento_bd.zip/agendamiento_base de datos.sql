-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-05-2025 a las 20:02:31
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `agendamiento`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria_categoria`
--

CREATE TABLE `auditoria_categoria` (
  `idAuditoria` int(11) NOT NULL,
  `idCategoria` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `accion` varchar(10) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria_doctor`
--

CREATE TABLE `auditoria_doctor` (
  `id` int(11) NOT NULL,
  `idDoc` int(11) DEFAULT NULL,
  `nombreCompleto` varchar(100) DEFAULT NULL,
  `accion` varchar(10) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auditoria_doctor`
--

INSERT INTO `auditoria_doctor` (`id`, `idDoc`, `nombreCompleto`, `accion`, `fecha`) VALUES
(1, 1, 'Dr. Pedro Morales', 'INSERT', '2025-05-26 03:24:30'),
(2, 2, 'Dra. Ana Torres', 'INSERT', '2025-05-26 03:24:30'),
(3, 3, 'Dr. Luis García', 'INSERT', '2025-05-26 03:24:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria_paciente`
--

CREATE TABLE `auditoria_paciente` (
  `idAuditoria` int(11) NOT NULL,
  `idPaciente` int(11) DEFAULT NULL,
  `nombrePaciente` varchar(100) DEFAULT NULL,
  `accion` varchar(10) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `auditoria_paciente`
--

INSERT INTO `auditoria_paciente` (`idAuditoria`, `idPaciente`, `nombrePaciente`, `accion`, `fecha`) VALUES
(1, 10, 'Juan Pérez', 'INSERT', '2025-05-26 03:23:20'),
(2, 11, 'María López', 'INSERT', '2025-05-26 03:23:20'),
(3, 12, 'Carlos Ríos', 'INSERT', '2025-05-26 03:23:20'),
(4, 13, 'Lucía Fernández', 'INSERT', '2025-05-26 03:23:20');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE `categoria` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `estado` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id`, `nombre`, `descripcion`, `estado`) VALUES
(1, 'Pediatría', 'Área médica especializada en la atención de niños.', 'Activo'),
(2, 'Cardiología', 'Estudio y tratamiento del corazón.', 'Activo'),
(3, 'Dermatología', 'Especialidad enfocada en enfermedades de la piel.', 'Activo'),
(4, 'Geriatría', 'Atención médica para adultos mayores.', 'Inactivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `doctor`
--

CREATE TABLE `doctor` (
  `idDoc` int(11) NOT NULL,
  `dni` varchar(15) NOT NULL,
  `nombreCompleto` varchar(100) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `estadoCivil` varchar(30) DEFAULT NULL,
  `genero` varchar(15) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `formacionAcademica` text DEFAULT NULL,
  `experienciaLaboral` text DEFAULT NULL,
  `añosServicio` int(11) DEFAULT NULL,
  `horarioAtencion` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `doctor`
--

INSERT INTO `doctor` (`idDoc`, `dni`, `nombreCompleto`, `edad`, `telefono`, `estadoCivil`, `genero`, `direccion`, `formacionAcademica`, `experienciaLaboral`, `añosServicio`, `horarioAtencion`, `email`) VALUES
(1, '43215678', 'Dr. Pedro Morales', 45, '999888777', 'Casado', 'Masculino', 'Av. Perú 123', 'Medicina General', '10 años en Hospital Nacional', 10, '08:00 - 14:00', 'pmorales@clinica.pe'),
(2, '56781234', 'Dra. Ana Torres', 38, '912345679', 'Soltera', 'Femenino', 'Calle San Martín 456', 'Ginecología', '8 años en clínica privada', 8, '10:00 - 16:00', 'atorres@salud.pe'),
(3, '78903456', 'Dr. Luis García', 50, '987654320', 'Viudo', 'Masculino', 'Jr. Ayacucho 789', 'Pediatría', '15 años en Hospital del Niño', 15, '07:00 - 13:00', 'lgarcia@hospitalnino.pe');

--
-- Disparadores `doctor`
--
DELIMITER $$
CREATE TRIGGER `after_delete_doctor` AFTER DELETE ON `doctor` FOR EACH ROW INSERT INTO auditoria_doctor (idDoc, nombreCompleto, accion)
VALUES (OLD.idDoc, OLD.nombreCompleto, 'DELETE')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_insert_doctor` AFTER INSERT ON `doctor` FOR EACH ROW INSERT INTO auditoria_doctor (idDoc, nombreCompleto, accion)
VALUES (NEW.idDoc, NEW.nombreCompleto, 'INSERT')
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_update_doctor` AFTER UPDATE ON `doctor` FOR EACH ROW INSERT INTO auditoria_doctor (idDoc, nombreCompleto, accion)
VALUES (NEW.idDoc, NEW.nombreCompleto, 'UPDATE')
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `historial_clinica`
--

CREATE TABLE `historial_clinica` (
  `idPaciente` int(11) NOT NULL,
  `titulo` varchar(20) DEFAULT NULL,
  `nombres` varchar(100) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `domicilio` text DEFAULT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `estado` varchar(50) DEFAULT NULL,
  `codigoPostal` varchar(10) DEFAULT NULL,
  `idMedico` int(11) DEFAULT NULL,
  `sexo` varchar(10) DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  `lugarNacimiento` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `numSeguroSocial` varchar(50) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `telefonoDom` varchar(20) DEFAULT NULL,
  `telefonoOficina` varchar(20) DEFAULT NULL,
  `observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `historial_clinica`
--

INSERT INTO `historial_clinica` (`idPaciente`, `titulo`, `nombres`, `apellidos`, `domicilio`, `ciudad`, `estado`, `codigoPostal`, `idMedico`, `sexo`, `fechaNacimiento`, `lugarNacimiento`, `correo`, `numSeguroSocial`, `edad`, `telefonoDom`, `telefonoOficina`, `observaciones`) VALUES
(1, 'Sr.', 'Juan', 'Pérez Ramírez', 'Av. Siempre Viva 123', 'Lima', 'activo', '15001', 1, 'Masculino', '1989-03-15', 'Arequipa', 'juan.perez@mail.com', '12345678901', 35, '987654321', '012345678', 'Paciente sin antecedentes importantes.'),
(2, 'Sra.', 'María', 'López Gutiérrez', 'Calle Luna 456', 'Trujillo', 'activo', '13001', 2, 'Femenino', '1995-07-21', 'Trujillo', 'maria.lopez@mail.com', '98765432109', 29, '912345678', '022334455', 'Alergia leve a penicilina.'),
(3, 'Dr.', 'Carlos', 'Ríos Vega', 'Jr. Los Olivos 777', 'Cusco', 'activo', '08001', 1, 'Masculino', '1982-12-05', 'Cusco', 'carlos.rios@mail.com', '56789012345', 42, '901112233', '098765432', 'Ex fumador, hipertensión controlada.'),
(4, 'Lic.', 'Lucía', 'Fernández Soto', 'Psje. Esperanza 100', 'Chiclayo', 'activo', '14001', 3, 'Femenino', '1993-09-10', 'Chiclayo', 'lucia.fernandez@mail.com', '34567890123', 31, '923456789', '033445566', 'Asma leve desde infancia.');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paciente`
--

CREATE TABLE `paciente` (
  `idPaciente` int(11) NOT NULL,
  `dni` varchar(20) NOT NULL,
  `nombrePaciente` varchar(150) NOT NULL,
  `direccion` text DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `tipoSeguro` varchar(50) DEFAULT NULL,
  `genero` varchar(10) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `tipoSangre` varchar(10) DEFAULT NULL,
  `referenciado` varchar(100) DEFAULT NULL,
  `profesion` varchar(100) DEFAULT NULL,
  `nHijos` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `paciente`
--

INSERT INTO `paciente` (`idPaciente`, `dni`, `nombrePaciente`, `direccion`, `telefono`, `tipoSeguro`, `genero`, `edad`, `tipoSangre`, `referenciado`, `profesion`, `nHijos`) VALUES
(10, '12345678', 'Juan Pérez', 'Av. Siempre Viva 123', '987654321', 'Essalud', 'Masculino', 35, 'O+', 'Hospital Nacional', 'Ingeniero', 2),
(11, '87654321', 'María López', 'Calle Luna 456', '912345678', 'SIS', 'Femenino', 29, 'A-', 'Clínica San Juan', 'Doctora', 1),
(12, '11223344', 'Carlos Ríos', 'Jr. Los Olivos 777', '901112233', 'Particular', 'Masculino', 42, 'B+', 'Centro Médico El Sol', 'Abogado', 3),
(13, '99887766', 'Lucía Fernández', 'Psje. Esperanza 100', '923456789', 'SIS', 'Femenino', 31, 'O-', 'Hospital Regional', 'Contadora', 0);

--
-- Disparadores `paciente`
--
DELIMITER $$
CREATE TRIGGER `after_insert_paciente` AFTER INSERT ON `paciente` FOR EACH ROW BEGIN
    INSERT INTO auditoria_paciente (idPaciente, nombrePaciente, accion)
    VALUES (NEW.idPaciente, NEW.nombrePaciente, 'INSERT');
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `auditoria_categoria`
--
ALTER TABLE `auditoria_categoria`
  ADD PRIMARY KEY (`idAuditoria`);

--
-- Indices de la tabla `auditoria_doctor`
--
ALTER TABLE `auditoria_doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `auditoria_paciente`
--
ALTER TABLE `auditoria_paciente`
  ADD PRIMARY KEY (`idAuditoria`);

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`idDoc`),
  ADD UNIQUE KEY `dni` (`dni`);

--
-- Indices de la tabla `historial_clinica`
--
ALTER TABLE `historial_clinica`
  ADD PRIMARY KEY (`idPaciente`);

--
-- Indices de la tabla `paciente`
--
ALTER TABLE `paciente`
  ADD PRIMARY KEY (`idPaciente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `auditoria_categoria`
--
ALTER TABLE `auditoria_categoria`
  MODIFY `idAuditoria` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `auditoria_doctor`
--
ALTER TABLE `auditoria_doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `auditoria_paciente`
--
ALTER TABLE `auditoria_paciente`
  MODIFY `idAuditoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `doctor`
--
ALTER TABLE `doctor`
  MODIFY `idDoc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `historial_clinica`
--
ALTER TABLE `historial_clinica`
  MODIFY `idPaciente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `paciente`
--
ALTER TABLE `paciente`
  MODIFY `idPaciente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
