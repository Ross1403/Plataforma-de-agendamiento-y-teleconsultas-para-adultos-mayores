
package Controlador;

import dao.DAO_Especialidades;
import Modelo.Especialidad;
import java.util.List;

public class ControlEspecialidades {
    /*private DAO_Especialidades daoEspecialidades;

    public ControlEspecialidades() {
        daoEspecialidades = new DAO_Especialidades();
    }

    public boolean registrarEspecialidad(Especialidad especialidad) {
        return daoEspecialidades.insertar(especialidad);
    }

    public boolean actualizarEspecialidad(Especialidad especialidad) {
        return daoEspecialidades.actualizar(especialidad);
    }

    public boolean eliminarEspecialidad(int id) {
        return daoEspecialidades.eliminar(id);
    }

    public List<Especialidad> obtenerEspecialidades() {
        return daoEspecialidades.listar();
    }*/
}
