
package Configuracion;
/*
    D: Data
    A: Access
    O: Object
*/
public interface Parametros {
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String RUTA = "jdbc:mysql://localhost:3309/bdPostaClinica";
    String USUARIO = "root";
    String CLAVE = "";
}
